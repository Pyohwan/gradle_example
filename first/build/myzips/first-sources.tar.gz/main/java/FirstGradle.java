public class FirstGradle {
	public FirstGradle() {
	}

	public static void main(String arg[]) {
		FirstGradle gradle = new FirstGradle();
		System.out.println("Hello Gradle with Java");
	}
}
